import { auth, db } from '../firebase.js';
import {
  doc, getDoc, updateDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

const params = new URLSearchParams(location.search);
const id = params.get("id");

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    location.href = "./login.html";
    return;
  }

  const docRef = doc(db, "notices", id);
  const docSnap = await getDoc(docRef);
  const data = docSnap.data();

  if (!data) {
    alert("존재하지 않는 공지입니다.");
    location.href = "./notice_list.html";
    return;
  }

  if (data.writer !== user.uid) {
    alert("수정 권한이 없습니다.");
    location.href = "./notice_list.html";
    return;
  }

  document.getElementById("title").value = data.title;
  document.getElementById("content").value = data.content;

  document.getElementById("updateBtn").addEventListener("click", async () => {
    const updatedTitle = document.getElementById("title").value;
    const updatedContent = document.getElementById("content").value;

    await updateDoc(docRef, {
      title: updatedTitle,
      content: updatedContent
    });

    alert("수정되었습니다.");
    window.location.href = `./notice_detail.html?id=${id}`;
  });
});
