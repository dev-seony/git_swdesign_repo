import { auth, db } from '../firebase.js';
import {
  collection, addDoc, serverTimestamp, doc, getDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    window.location.href = "./login.html";
    return;
  }

  const userDoc = await getDoc(doc(db, "members", user.uid));
  const userData = userDoc.data();
  if (!userData || !userData.admin) {
    alert("관리자만 공지사항을 작성할 수 있습니다.");
    window.location.href = "./notice_list.html";
    return;
  }

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;

    if (!title || !content) {
      alert("제목과 내용을 모두 입력해주세요.");
      return;
    }

    try {
      await addDoc(collection(db, "notices"), {
        title,
        content,
        date: new Date().toLocaleDateString(),
        timestamp: serverTimestamp(),
        writer: user.uid
      });
      alert("공지사항이 등록되었습니다.");
      window.location.href = "./notice_list.html";
    } catch (e) {
      alert("등록 실패: " + e.message);
    }
  });
});