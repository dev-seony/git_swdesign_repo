import { auth, db } from '../firebase.js';
import {
  collection, getDocs, deleteDoc, doc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    location.href = "./login.html";
    return;
  }

  const adminSnap = await getDocs(collection(db, "members"));
  let isAdmin = false;
  adminSnap.forEach(d => {
    if (d.id === user.uid && d.data().admin) {
      isAdmin = true;
    }
  });

  if (!isAdmin) {
    alert("접근 권한이 없습니다.");
    location.href = "./dashboard.html";
    return;
  }

  const list = document.getElementById("userList");
  const snapshot = await getDocs(collection(db, "members"));

  snapshot.forEach(docSnap => {
    const data = docSnap.data();

    // 최상위 li
    const li = document.createElement("li");

    // 사용자 정보 영역
    const infoDiv = document.createElement("div");
    infoDiv.className = "user-info";
    infoDiv.textContent = `${data.name} (${data.email}) - ${data.department}`;

    // 버튼 영역
    const actionDiv = document.createElement("div");
    actionDiv.className = "user-actions";

    const editBtn = document.createElement("button");
    editBtn.textContent = "수정";
    editBtn.onclick = () => {
      window.location.href = `./user_edit.html?uid=${docSnap.id}`;
    };

    const delBtn = document.createElement("button");
    delBtn.textContent = "삭제";
    delBtn.onclick = async () => {
      const ok = confirm("정말 삭제하시겠습니까?");
      if (!ok) return;
      await deleteDoc(doc(db, "members", docSnap.id));
      alert("삭제되었습니다.");
      location.reload();
    };

    actionDiv.appendChild(editBtn);
    actionDiv.appendChild(delBtn);

    li.appendChild(infoDiv);
    li.appendChild(actionDiv);
    list.appendChild(li);
  });
});
