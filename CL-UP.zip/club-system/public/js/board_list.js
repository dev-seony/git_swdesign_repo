import { db } from '../firebase.js';
import {
  collection, query, orderBy, getDocs
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

window.addEventListener("DOMContentLoaded", async () => {
  const postList = document.getElementById("boardList");
  const q = query(collection(db, "clubs"), orderBy("timestamp", "desc"));
  const querySnapshot = await getDocs(q);

  querySnapshot.forEach((doc) => {
    const data = doc.data();
    const li = document.createElement("li");
    li.innerHTML = `
      <a href="./board_detail.html?id=${doc.id}"><strong>${data.title}</strong></a><br>
      분야: ${data.category || '-'}<br>
      활동 요일: ${data.weekday || '-'}<br>
      등록일: ${data.date || '-'}
      <hr>
    `;
    postList.appendChild(li);
  });
});
