import { auth, db } from "../firebase.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";
import {
  doc, setDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", () => {
  const signupBtn = document.querySelector("button#signupBtn");
  if (signupBtn) {
    signupBtn.addEventListener("click", async () => {
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;
      const department = document.getElementById("department").value.trim();
      const interests = [...document.querySelectorAll("input[name='interests']:checked")].map(el => el.value);

      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const uid = userCredential.user.uid;

        await setDoc(doc(db, "members", uid), {
          name,
          email,
          department,
          category: interests,
          admin: false,
          clubManager: false,
          clubMember: false,
          clubsJoined: [],
          clubsManaged: []
        });

        alert("회원가입 성공!");
        window.location.href = "./login.html";
      } catch (error) {
        alert("회원가입 실패: " + error.message);
        console.error(error);
      }
    });
  }

  const loginBtn = document.querySelector("button#loginBtn");
  if (loginBtn) {
    loginBtn.addEventListener("click", async () => {
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;

      try {
        await signInWithEmailAndPassword(auth, email, password);
        alert("로그인 성공!");
        window.location.href = "./index.html";
      } catch (error) {
        alert("로그인 실패: " + error.message);
        console.error(error);
      }
    });
  }
});
