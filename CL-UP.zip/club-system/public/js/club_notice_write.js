import { auth, db } from '../firebase.js';
import {
  collection, addDoc, serverTimestamp, doc, getDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    location.href = "./login.html";
    return;
  }

  const userSnap = await getDoc(doc(db, "members", user.uid));
  const userData = userSnap.data();
  const managedClubs = Array.isArray(userData.clubsManaged) ? userData.clubsManaged : [];

  if (managedClubs.length === 0) {
    document.getElementById("accessDenied").style.display = "block";
    return;
  }

  const selector = document.getElementById("clubSelector");

  for (const clubId of managedClubs) {
    const clubSnap = await getDoc(doc(db, "clubs", clubId));
    if (clubSnap.exists()) {
      const option = document.createElement("option");
      option.value = clubId;
      option.textContent = clubSnap.data().title;
      selector.appendChild(option);
    }
  }

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const selectedClubId = selector.value;
    const title = document.getElementById("title").value.trim();
    const content = document.getElementById("content").value.trim();

    if (!title || !content) {
      alert("제목과 내용을 모두 입력해주세요.");
      return;
    }

    try {
      await addDoc(collection(db, "club_notices"), {
        title,
        content,
        clubId: selectedClubId,
        writer: user.uid,
        writerName: userData.name || '',
        timestamp: serverTimestamp(),
        date: new Date().toLocaleDateString()
      });

      alert("공지사항이 등록되었습니다.");
      window.location.href = "./club_notice_list.html";
    } catch (e) {
      alert("등록 실패: " + e.message);
    }
  });
});
