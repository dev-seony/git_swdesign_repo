import { auth, db } from "../firebase.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";
import {
  collection, getDocs, doc, getDoc, deleteDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    window.location.href = "./login.html";
    return;
  }

  const memberSnap = await getDoc(doc(db, "members", user.uid));
  const member = memberSnap.exists() ? memberSnap.data() : {};

  if (member.admin) {
    document.getElementById("writeLink").style.display = "inline";
  }

  const list = document.getElementById("noticeList");
  const snapshot = await getDocs(collection(db, "notices"));

  if (snapshot.empty) {
    const empty = document.createElement("li");
    empty.innerText = "등록된 공지사항이 없습니다.";
    list.appendChild(empty);
    return;
  }

  snapshot.forEach(docSnap => {
    const data = docSnap.data();
    const li = document.createElement("li");
    li.innerHTML = `
      <a href="./notice_detail.html?id=${docSnap.id}">${data.title}</a> - ${data.date}
      ${member.admin ? `<button onclick="deleteNotice('${docSnap.id}')">삭제</button>` : ''}
    `;
    list.appendChild(li);
  });
});

window.deleteNotice = async function (id) {
  const ok = confirm("정말 삭제하시겠습니까?");
  if (!ok) return;

  try {
    await deleteDoc(doc(db, "notices", id));
    alert("삭제되었습니다.");
    window.location.reload();
  } catch (e) {
    console.error("삭제 실패:", e);
    alert("삭제 중 오류가 발생했습니다.");
  }
};
