import { auth, db } from '../firebase.js';
import {
  doc, getDoc, updateDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

const params = new URLSearchParams(location.search);
const id = params.get("id");

onAuthStateChanged(auth, async (user) => {
  if (!user || !id) {
    alert("잘못된 접근입니다.");
    location.href = "./login.html";
    return;
  }

  const docRef = doc(db, "clubs", id);
  const docSnap = await getDoc(docRef);
  const data = docSnap.data();

  if (!data || user.uid !== data.writer) {
    alert("수정 권한이 없습니다.");
    window.location.href = "./board_list.html";
    return;
  }

  document.getElementById("title").value = data.title;
  document.getElementById("content").value = data.content;
  document.getElementById("category").value = data.category || "";
  document.getElementById("weekday").value = data.weekday || "";
  document.getElementById("condition").value = data.condition || "";
  document.getElementById("fee").value = data.fee || "";

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;
    const category = document.getElementById("category").value;
    const weekday = document.getElementById("weekday").value;
    const condition = document.getElementById("condition").value;
    const fee = document.getElementById("fee").value;

    if (!title || !content || !category || !weekday || !condition || !fee) {
      alert("모든 항목을 입력해주세요.");
      return;
    }

    await updateDoc(docRef, {
      title,
      content,
      category,
      weekday,
      condition,
      fee
    });

    alert("수정 완료되었습니다.");
    window.location.href = `./board_detail.html?id=${id}`;
  });
});
