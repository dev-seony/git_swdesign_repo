import { auth, db } from '../firebase.js';
import {
  collection, getDocs, addDoc, doc, getDoc, query, where
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    window.location.href = "./login.html";
    return;
  }

  const memberDoc = await getDoc(doc(db, "members", user.uid));
  const memberData = memberDoc.data();
  const clubsJoined = Array.isArray(memberData.clubsJoined) ? memberData.clubsJoined : [];

  const clubsSnap = await getDocs(collection(db, "clubs"));
  const select = document.getElementById("clubSelect");
  clubsSnap.forEach(docSnap => {
    const clubId = docSnap.id;
    const clubTitle = docSnap.data().title;
    if (!clubsJoined.includes(clubId)) {
      const option = document.createElement("option");
      option.value = clubId;
      option.innerText = clubTitle;
      select.appendChild(option);
    }
  });

  document.getElementById("applyBtn").addEventListener("click", async () => {
    const clubId = select.value;

    if (!clubId) {
      alert("신청할 동아리를 선택해주세요.");
      return;
    }

    const q = query(
      collection(db, "club_applications"),
      where("userId", "==", user.uid),
      where("clubId", "==", clubId),
      where("approved", "==", false)
    );
    const existingSnap = await getDocs(q);

    if (!existingSnap.empty) {
      alert("이미 해당 동아리에 신청 중입니다.");
      return;
    }

    try {
      await addDoc(collection(db, "club_applications"), {
        userId: user.uid,
        clubId,
        approved: false,
        requestedAt: new Date()
      });
      alert("신청이 완료되었습니다. 승인 대기 중입니다.");
      window.location.href = "./index.html";
    } catch (e) {
      alert("신청 실패: " + e.message);
    }
  });
});
