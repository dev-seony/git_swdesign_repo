import { auth, db } from '../firebase.js';
import {
  doc, getDoc, collection, getDocs
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    location.href = "./login.html";
    return;
  }

  const userRef = doc(db, "members", user.uid);
  const userSnap = await getDoc(userRef);
  const userData = userSnap.data();

  const welcome = document.getElementById("welcome");
  welcome.innerText = `🎉 ${userData.name || "회원"}님 환영합니다!`;

  const board = document.getElementById("ai-recommendation-box");
  const clubsSnap = await getDocs(collection(db, "clubs"));
  const matchedClubs = [];

  clubsSnap.forEach(doc => {
    const c = doc.data();
    if (userData.category?.includes(c.category)) {
      matchedClubs.push(c.title);
    }
  });

  if (matchedClubs.length > 0) {
    board.innerText = `✨ 관심사와 맞는 동아리: ${matchedClubs.join(', ')} ✨`;
  } else {
    board.innerText = `관심사와 일치하는 동아리가 아직 없어요.`;
  }

  if (!userData.admin && !userData.clubManager) {
    document.getElementById("user-only").style.display = "block";
  }
  if (userData.admin) {
    document.getElementById("admin-only").style.display = "block";
  }
  if (userData.clubManager) {
    document.getElementById("club-admin-only").style.display = "block";
  }
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  await signOut(auth);
  alert("로그아웃 되었습니다.");
  location.href = "./index.html";
});
