import { auth, db } from "../firebase.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";
import {
  collection, query, getDocs, updateDoc, doc, getDoc, arrayUnion, arrayRemove, where
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

const params = new URLSearchParams(location.search);
const clubId = params.get("clubId");

onAuthStateChanged(auth, async (user) => {
  if (!user || !clubId) {
    alert("잘못된 접근입니다.");
    location.href = "./index.html";
    return;
  }

  const userRef = doc(db, "members", user.uid);
  const userSnap = await getDoc(userRef);
  const userData = userSnap.data();

  const isManager = Array.isArray(userData.clubsManaged) && userData.clubsManaged.includes(clubId);
  if (!isManager) {
    alert("해당 동아리의 관리자만 접근 가능합니다.");
    location.href = "./index.html";
    return;
  }

  const membersQuery = query(
    collection(db, "members"),
    where("clubsJoined", "array-contains", clubId)
  );
  const snapshot = await getDocs(membersQuery);
  const list = document.getElementById("memberList");

  snapshot.forEach((docSnap) => {
    const data = docSnap.data();
    const li = document.createElement("li");
    li.textContent = `${data.name} (${data.email})`;

    const manages = Array.isArray(data.clubsManaged) && data.clubsManaged.includes(clubId);

    if (docSnap.id !== user.uid) {
      const btn = document.createElement("button");
      btn.textContent = manages ? "관리자 해제" : "관리자로 지정";
      btn.onclick = async () => {
        const update = manages
          ? { clubsManaged: arrayRemove(clubId) }
          : { clubsManaged: arrayUnion(clubId) };
        await updateDoc(doc(db, "members", docSnap.id), update);
        alert(`사용자의 관리자 권한이 ${manages ? '해제' : '부여'}되었습니다.`);
        location.reload();
      };
      li.appendChild(btn);
    } else {
      li.innerHTML += " - (당신)";
    }

    list.appendChild(li);
  });
});
