import { auth, db } from '../firebase.js';
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

const params = new URLSearchParams(location.search);
const id = params.get("id");

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    window.location.href = "./login.html";
    return;
  }

  const userSnap = await getDoc(doc(db, "members", user.uid));
  const userData = userSnap.data();
  const isManager = userData?.clubManager;

  const docSnap = await getDoc(doc(db, "club_notices", id));
  const data = docSnap.data();

  document.getElementById("title").innerText = data.title;
  document.getElementById("content").innerText = data.content;
  document.getElementById("meta").innerText = `작성자: ${data.writerName || '-'}, 등록일: ${data.date}`;

  if (isManager && data.writer === user.uid) {
    document.getElementById("editBox").style.display = "block";
    document.getElementById("editBtn").onclick = () => {
      window.location.href = `./club_notice_edit.html?id=${id}`;
    };
  }
});