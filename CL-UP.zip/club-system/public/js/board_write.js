import { auth, db } from '../firebase.js';
import {
  collection, addDoc, serverTimestamp, updateDoc, doc, arrayUnion
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    window.location.href = "./login.html";
    return;
  }

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const title = document.getElementById("title").value.trim();
    const content = document.getElementById("content").value.trim();
    const category = document.getElementById("category").value;
    const weekday = document.getElementById("weekday").value.trim();
    const condition = document.getElementById("condition").value.trim();
    const fee = document.getElementById("fee").value.trim();

    if (!title || !content || !category || !weekday || !condition || !fee) {
      alert("모든 항목을 입력해주세요.");
      return;
    }

    try {
      const clubDoc = await addDoc(collection(db, "clubs"), {
        title,
        content,
        category,
        weekday,
        condition,
        fee,
        writer: user.uid,
        date: new Date().toLocaleDateString(),
        timestamp: serverTimestamp()
      });

      const userRef = doc(db, "members", user.uid);
      await updateDoc(userRef, {
        clubManager: true,
        clubMember: true,
        clubsManaged: arrayUnion(clubDoc.id),
        clubsJoined: arrayUnion(clubDoc.id)
      });

      alert("동아리 모집글이 등록되었고, 관리자 권한이 부여되었습니다.");
      window.location.href = "./board_list.html";
    } catch (e) {
      alert("등록 실패: " + e.message);
    }
  });
});
