import { auth, db } from '../firebase.js';
import {
  doc, getDoc, deleteDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

const params = new URLSearchParams(location.search);
const id = params.get("id");

onAuthStateChanged(auth, async (user) => {
  if (!user || !id) {
    alert("잘못된 접근입니다.");
    location.href = "./login.html";
    return;
  }

  const docRef = doc(db, "clubs", id);
  const docSnap = await getDoc(docRef);
  const data = docSnap.data();

  if (!data) {
    alert("존재하지 않는 게시글입니다.");
    location.href = "./board_list.html";
    return;
  }

  document.getElementById("title").textContent = data.title;
  document.getElementById("content").textContent = data.content;
  document.getElementById("date").textContent = data.date || "";

  const extra = document.getElementById("extraInfo");
  extra.innerHTML = `
    분야: ${data.category || '-'}<br>
    활동 요일: ${data.weekday || '-'}<br>
    가입 조건: ${data.condition || '-'}<br>
    가입비: ${data.fee || '-'}<br>
  `;

  if (user.uid === data.writer) {
    const controls = document.getElementById("controls");
    const editBtn = document.createElement("button");
    editBtn.textContent = "수정";
    editBtn.onclick = () => window.location.href = `./board_edit.html?id=${id}`;
    controls.appendChild(editBtn);

    const delBtn = document.createElement("button");
    delBtn.textContent = "삭제";
    delBtn.onclick = async () => {
      const ok = confirm("정말 삭제하시겠습니까?");
      if (!ok) return;
      await deleteDoc(doc(db, "posts", id));
      alert("삭제되었습니다.");
      window.location.href = "./board_list.html";
    };
    controls.appendChild(delBtn);
  }
});
