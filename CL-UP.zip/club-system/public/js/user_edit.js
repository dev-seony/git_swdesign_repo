import { auth, db } from '../firebase.js';
import {
  doc, getDoc, updateDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

const params = new URLSearchParams(location.search);
const uidParam = params.get("uid");

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    location.href = "./login.html";
    return;
  }

  const targetUid = uidParam || user.uid;
  const memberRef = doc(db, "members", targetUid);
  const memberSnap = await getDoc(memberRef);

  if (!memberSnap.exists()) {
    alert("해당 사용자를 찾을 수 없습니다.");
    location.href = "./dashboard.html";
    return;
  }

  const data = memberSnap.data();
  const currentUserSnap = await getDoc(doc(db, "members", user.uid));
  const currentUser = currentUserSnap.data();

  if (user.uid !== targetUid && !currentUser.admin) {
    alert("수정 권한이 없습니다.");
    location.href = "./dashboard.html";
    return;
  }

  document.getElementById("name").value = data.name || '';
  document.getElementById("department").value = data.department || '';

  // 🔹 체크된 항목 세팅
  const categoryCheckboxes = document.querySelectorAll("input[name='category']");
  if (Array.isArray(data.category)) {
    for (const box of categoryCheckboxes) {
      if (data.category.includes(box.value)) {
        box.checked = true;
      }
    }
  }

  const titleElement = document.querySelector("h2");
  if (user.uid !== targetUid && currentUser.admin) {
    titleElement.textContent = "회원 정보 수정";
  } else {
    titleElement.textContent = "내 정보 수정";
  }
  
  document.getElementById("saveBtn").addEventListener("click", async () => {
    const name = document.getElementById("name").value;
    const department = document.getElementById("department").value;

    const selectedCategories = [...categoryCheckboxes]
      .filter(box => box.checked)
      .map(box => box.value);

    await updateDoc(memberRef, {
      name,
      department,
      category: selectedCategories
    });

    alert("정보가 수정되었습니다.");
    location.href = "./dashboard.html";
  });
});
