import { auth, db } from '../firebase.js';
import {
  collection, query, orderBy, getDocs, doc, getDoc, deleteDoc
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    location.href = "./login.html";
    return;
  }

  const userSnap = await getDoc(doc(db, "members", user.uid));
  const userData = userSnap.data();
  const managedClubs = Array.isArray(userData.clubsManaged) ? userData.clubsManaged : [];
  const joinedClubs = Array.isArray(userData.clubsJoined) ? userData.clubsJoined : [];

  // 공지 작성 링크 표시
  const writeContainer = document.getElementById("writeLinkContainer");
  if (managedClubs.length > 0 && writeContainer) {
    writeContainer.style.display = "block";
    writeContainer.innerHTML = "<strong>[공지 작성]</strong><br>";

    for (const clubId of managedClubs) {
      const clubSnap = await getDoc(doc(db, "clubs", clubId));
      if (clubSnap.exists()) {
        const clubData = clubSnap.data();
        const link = document.createElement("a");
        link.href = `./club_notice_write.html?clubId=${clubId}`;
        link.textContent = `➔ ${clubData.title} 공지 작성`;
        link.style.display = "block";
        writeContainer.appendChild(link);
      }
    }
  }

  const noticeList = document.getElementById("noticeList");
  const emptyMessage = document.getElementById("emptyMessage");

  const q = query(
    collection(db, "club_notices"),
    orderBy("timestamp", "desc")
  );

  try {
    const querySnapshot = await getDocs(q);

    let hasAnyNotice = false;

    for (const docSnap of querySnapshot.docs) {
      const data = docSnap.data();
      const clubId = data.clubId;

      if (!joinedClubs.includes(clubId)) continue;

      const clubSnap = await getDoc(doc(db, "clubs", clubId));
      const clubData = clubSnap.exists() ? clubSnap.data() : { title: "(알 수 없음)" };

      const li = document.createElement("li");
      li.innerHTML = `
        <strong>${data.title}</strong><br>
       동아리: ${clubData.title}<br>
       ${data.content}<br>
       작성자: ${data.writerName || '-'}<br>
       등록일: ${data.date}<br>
       <a href="./club_notice_detail.html?id=${docSnap.id}&clubId=${clubId}">[상세보기]</a>
       ${managedClubs.includes(clubId) ? `<button onclick="deleteNotice('${docSnap.id}', '${clubId}')">삭제</button>` : ''}
       <hr>
      `;
      noticeList.appendChild(li);

      hasAnyNotice = true;
    }

    if (!hasAnyNotice) {
      emptyMessage.style.display = "block";
    }
  } catch (e) {
    console.error("공지 불러오기 실패:", e);
    alert("공지사항을 불러오는데 실패했습니다.");
  }
});

window.deleteNotice = async function (id, clubId) {
  const user = auth.currentUser;
  if (!user) {
    alert("로그인이 필요합니다.");
    return;
  }

  const userSnap = await getDoc(doc(db, "members", user.uid));
  const userData = userSnap.data();
  const managedClubs = Array.isArray(userData.clubsManaged) ? userData.clubsManaged : [];

  if (!managedClubs.includes(clubId)) {
    alert("해당 동아리의 관리자만 삭제할 수 있습니다.");
    return;
  }

  const ok = confirm("정말 삭제하시겠습니까?");
  if (!ok) return;

  try {
    await deleteDoc(doc(db, "club_notices", id));
    alert("삭제되었습니다.");
    window.location.reload();
  } catch (e) {
    console.error("삭제 실패:", e);
    alert("삭제 중 오류가 발생했습니다.");
  }
};
