import { initializeApp } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyChNiMrFQt9IiV2mDW_DkO7gZXoVR6VFFQ",
  authDomain: "club-system-caeda.firebaseapp.com",
  projectId: "club-system-caeda",
  storageBucket: "club-system-caeda.firebasestorage.app",
  messagingSenderId: "374510665912",
  appId: "1:374510665912:web:51a8a00ac341209903344d",
  measurementId: "G-TYJ81F1SD0"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
