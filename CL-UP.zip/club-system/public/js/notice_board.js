import { db } from '../firebase.js';
import {
  collection, getDocs, query, orderBy
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const noticeList = document.getElementById("noticeList");

async function loadNotices() {
  const q = query(collection(db, "notices"), orderBy("createdAt", "desc"));
  const querySnapshot = await getDocs(q);

  querySnapshot.forEach((doc) => {
    const data = doc.data();
    const div = document.createElement("div");
    div.innerHTML = `
      <h3>${data.title}</h3>
      <p>작성자: ${data.author}</p>
      <p>${data.content}</p>
      <hr/>
    `;
    noticeList.appendChild(div);
  });
}

loadNotices();