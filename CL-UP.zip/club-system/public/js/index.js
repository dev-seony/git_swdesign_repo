import { auth, db } from "../firebase.js";
import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";
import {
  getDoc, doc, collection, getDocs
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

const menu = document.getElementById("menuList");

function createButton(text, href) {
  const btn = document.createElement("button");
  btn.textContent = text;
  btn.onclick = () => location.href = href;
  btn.className = "menu-button";
  return btn;
}

function insertDivider() {
  const hr = document.createElement("hr");
  hr.style.margin = "24px 0";
  menu.appendChild(hr);
}

function addLogoutButton() {
  const btn = document.createElement("button");
  btn.id = "logoutBtn";
  btn.textContent = "🚪 로그아웃";
  btn.className = "menu-button logout";
  menu.appendChild(btn);
}

onAuthStateChanged(auth, async (user) => {
  menu.innerHTML = "";

  if (!user) {
    menu.appendChild(createButton("🔐 로그인", "./login.html"));
    menu.appendChild(createButton("📝 회원가입", "./signup.html"));
    return;
  }

  menu.appendChild(createButton("📊 대시보드", "./dashboard.html"));
  menu.appendChild(createButton("📋 동아리 모집글", "./board_list.html"));
  menu.appendChild(createButton("✍️ 동아리 모집글 작성", "./board_write.html"));
  menu.appendChild(createButton("📢 전체 공지사항 목록", "./notice_list.html"));
  menu.appendChild(createButton("✅ 동아리 가입 신청", "./club_apply.html"));
  menu.appendChild(createButton("✏️ 내 정보 수정", "./user_edit.html"));

  const userDoc = await getDoc(doc(db, "members", user.uid));
  const userData = userDoc.data();

  if (userData?.admin) {
    menu.appendChild(createButton("📢 공지사항 작성", "./notice_write.html"));
    menu.appendChild(createButton("👑 가입 승인 (관리자용)", "./club_approve.html"));
    menu.appendChild(createButton("👥 회원 목록", "./user_list.html"));
  }

  const clubsSnap = await getDocs(collection(db, "clubs"));
  clubsSnap.forEach((docSnap) => {
    const club = docSnap.data();
    const clubId = docSnap.id;

    if (club.writer === user.uid) {
      insertDivider();
      menu.appendChild(createButton(`📢 ${club.title} 공지 작성`, `./club_notice_write.html?clubId=${clubId}`));
      menu.appendChild(createButton(`👤 가입 승인 (${club.title})`, `./club_approve.html?clubId=${clubId}`));
      menu.appendChild(createButton(`👑 ${club.title} 관리자 관리`, `./manager_manage.html?clubId=${clubId}`));
    }

    if (Array.isArray(userData?.clubsJoined) && userData.clubsJoined.includes(clubId)) {
      menu.appendChild(createButton(`🎓 ${club.title} 공지 목록`, `./club_notice_list.html?clubId=${clubId}`));
    }
  });
    insertDivider();
    addLogoutButton();
});

document.addEventListener("click", async (e) => {
  if (e.target && e.target.id === "logoutBtn") {
    e.preventDefault();
    try {
      await signOut(auth);
      alert("로그아웃 되었습니다.");
      window.location.href = "./index.html";
    } catch (error) {
      console.error("로그아웃 실패:", error);
      alert("로그아웃 중 오류가 발생했습니다.");
    }
  }
});
