import { auth, db } from '../firebase.js';
import {
  collection, query, where, getDocs, doc, updateDoc, getDoc, arrayUnion
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.8.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("로그인이 필요합니다.");
    window.location.href = "./login.html";
    return;
  }

  const userDoc = await getDoc(doc(db, "members", user.uid));
  const data = userDoc.data();

  if (!data.clubManager || !Array.isArray(data.clubsManaged)) {
    alert("동아리 관리자만 접근 가능합니다.");
    window.location.href = "./index.html";
    return;
  }

  const list = document.getElementById("applicationList");

  for (const clubId of data.clubsManaged) {
    const q = query(
      collection(db, "club_applications"),
      where("clubId", "==", clubId),
      where("approved", "==", false)
    );
    const snapshot = await getDocs(q);

    for (const docSnap of snapshot.docs) {
      const application = docSnap.data();
      const userDoc = await getDoc(doc(db, "members", application.userId));
      const userInfo = userDoc.data();

      const li = document.createElement("li");
      li.innerHTML = `
        ${userInfo.name} (${userInfo.email}) - 
        <button onclick="approve('${docSnap.id}', '${application.userId}', '${application.clubId}')">승인</button>
      `;
      list.appendChild(li);
    }
  }
});

window.approve = async function (docId, userId, clubId) {
  await updateDoc(doc(db, "club_applications", docId), {
    approved: true
  });

  await updateDoc(doc(db, "members", userId), {
    clubsJoined: arrayUnion(clubId),
    clubMember: true
  });

  alert("승인 완료");
  location.reload();
};
